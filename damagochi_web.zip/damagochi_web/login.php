<?php
// login.php
require_once "config.php";

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$username = trim($_POST['username'] ?? '');
$password = trim($_POST['password'] ?? '');

if ($username === '' || $password === '') {
    die("아이디와 비밀번호를 모두 입력하세요. <a href='login_form.php'>돌아가기</a>");
}

$stmt = $conn->prepare("SELECT id, username, password_hash FROM users WHERE username = ? LIMIT 1");
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
    $row = $result->fetch_assoc();
    if (password_verify($password, $row['password_hash'])) {
        $_SESSION['user_id'] = $row['id'];
        $_SESSION['username'] = $row['username'];

        $stmt = $conn->prepare("SELECT user_id, gold, last_action FROM gamedatas WHERE user_id = ?");
        $stmt->bind_param("i", $row['id']);
        $stmt->execute();
        $result = $stmt->get_result();
        $game_data = $result->fetch_assoc();

        $stmt = $conn1->prepare("INSERT INTO gamedatas (user_id, gold) VALUES (?, ?)");
        $stmt->bind_param("ii", $game_data['user_id'], $game_data['gold']);
        
        if(!$stmt->execute()){
            $stmt = $conn1->prepare("UPDATE gamedatas SET gold = ?, last_action = ? WHERE id = ?");
            $stmt->bind_param("isi", $game_data['gold'], $game_data['last_action'], $game_data['user_id']);
            $stmt->execute();
        }

        header("Location: dashboard.php");
        exit;
    } else {
        echo "비밀번호가 틀렸습니다. <a href='login_form.php'>다시 시도</a>";
    }
} else {
    echo "존재하지 않는 아이디입니다. <a href='register_form.php'>회원가입</a>";
}

$stmt->close();
$conn->close();
?>
